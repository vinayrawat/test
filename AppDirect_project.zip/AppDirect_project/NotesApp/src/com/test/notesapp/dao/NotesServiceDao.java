package com.test.notesapp.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.test.notesapp.model.Note;

public class NotesServiceDao {

	private static List<Note> notes;
	
	static{
		notes = setDummyNote();
	}

	public Note getNoteById(String id) {
		for(Note note: notes){
			if(note.getId().equals(id)){
				return note;
			}
		}
		return null;
	}

	private static List<Note> setDummyNote() {
		notes = new ArrayList<Note>();
		notes.add(new Note("0000", "sample note"));
		return notes;
	}

	public void addNote(Note note) {
		note.setTimestamp(new Timestamp(new Date().getTime()));
		notes.add(note);
	}

	public void updateNote(Note note) {
		notes.set(notes.indexOf(note), note);
	}

	public void deleteNoteById(String id) {
		for(Iterator<Note> iterator = notes.iterator(); iterator.hasNext();){
			 Note note = iterator.next();
			 if(note.getId().equals(id)){
				 iterator.remove();
				 break;
			 }
		}
	}

	public void markComplete(String id) {
		for(Iterator<Note> iterator = notes.iterator(); iterator.hasNext();){
			 Note note = iterator.next();
			 if(note.getId().equals(id)){
				 note.setComplete(true);
				 break;
			 }
		}
	}

	public List<Note> getAllNotes() {
		return notes;
	}

	public void deleteAllNotes() {
		notes.clear();
	}

	public boolean exist(Note note) {
		if(note != null){
			return getNoteById(note.getId()) != null;
		}
		return false;
	}

}
