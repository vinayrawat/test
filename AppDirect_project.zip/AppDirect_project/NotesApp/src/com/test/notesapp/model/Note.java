package com.test.notesapp.model;

import java.sql.Timestamp;
import java.util.Date;

public class Note {
	
	private String id;
	private String message;
	private Timestamp timestamp;
	private boolean isComplete;
	
	public Note(){
	}
	
	public Note(String id, String message){
		this.id = id;
		this.message = message;
		this.timestamp = new Timestamp(new Date().getTime());
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Timestamp getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}
	public boolean isComplete() {
		return isComplete;
	}
	public void setComplete(boolean isComplete) {
		this.isComplete = isComplete;
	}
	

}
