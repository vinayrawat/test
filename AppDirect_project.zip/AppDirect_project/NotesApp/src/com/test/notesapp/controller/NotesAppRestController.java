package com.test.notesapp.controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.test.notesapp.model.Note;
import com.test.notesapp.service.NotesService;


@RestController
public class NotesAppRestController {

	@Autowired
	NotesService notesService;
	
	@RequestMapping(value="/note/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Note> getNote(@PathVariable("id") String id){
		Note note = notesService.getNoteById(id);
		
		if (note == null){
			return new ResponseEntity<Note>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Note>(note, HttpStatus.OK);
	}
	
	@RequestMapping(value="/note/", method = RequestMethod.POST)
	public ResponseEntity<Void> addNote(@RequestBody Note note, UriComponentsBuilder ucBuilder){
	
        if (notesService.exist(note)) {
            return new ResponseEntity<Void>(HttpStatus.CONFLICT);
        }
 
        notesService.addNote(note);		
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/note/{id}").buildAndExpand(note.getId()).toUri());
        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);		
	}
	
	@RequestMapping(value="/updateNote/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Note> updateNote(@RequestBody Note note, @PathVariable("id") String id){
		Note currentNote = notesService.getNoteById(id);
		
		if (currentNote == null){
			return new ResponseEntity<Note>(HttpStatus.NOT_FOUND);
		}		
		
		currentNote.setMessage(note.getMessage());
		currentNote.setTimestamp(new Timestamp(new Date().getTime()));
		currentNote.setComplete(note.isComplete());
		
		notesService.updateNote(currentNote);
		return new ResponseEntity<Note>(currentNote, HttpStatus.OK);
	}
	
    @RequestMapping(value = "/note/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Note> deleteNoteById(@PathVariable("id") String id) {
		Note currentNote = notesService.getNoteById(id);
		
		if (currentNote == null){
			return new ResponseEntity<Note>(HttpStatus.NOT_FOUND);
		}
 
		notesService.deleteNoteById(id);
		
        return new ResponseEntity<Note>(HttpStatus.NO_CONTENT);
    }
    
	@RequestMapping(value="/markNoteComplete/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Note> markComplete(@PathVariable("id") String id){
		Note currentNote = notesService.getNoteById(id);
		
		if (currentNote == null){
			return new ResponseEntity<Note>(HttpStatus.NOT_FOUND);
		}		
		
		currentNote.setComplete(true);
		
		notesService.updateNote(currentNote);
		return new ResponseEntity<Note>(currentNote, HttpStatus.OK);
	}    
	
	@RequestMapping(value="/note/", method = RequestMethod.GET)
	public ResponseEntity<List<Note>> getAllNotes(){
		
		List<Note> notes = notesService.getAllNotes();
		if (notes.isEmpty()){
			return new ResponseEntity<List<Note>>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Note>>(notes, HttpStatus.OK);
	}	
	
    @RequestMapping(value = "/note/", method = RequestMethod.DELETE)
    public ResponseEntity<Note> deleteAllNotes() {
		notesService.deleteAllNotes();
        return new ResponseEntity<Note>(HttpStatus.NO_CONTENT);
    }	
	
}
