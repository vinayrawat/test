package com.test.notesapp.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.test.notesapp.dao.NotesServiceDao;
import com.test.notesapp.model.Note;

@Service("notesService")
@Transactional
public class NotesServiceImpl implements NotesService {
	
	NotesServiceDao notesDao = new NotesServiceDao();
	
	@Override
	public Note getNoteById(String id) {
		return notesDao.getNoteById(id);
	}

	@Override
	public void addNote(Note note) {
		notesDao.addNote(note);
	}

	@Override
	public void updateNote(Note note) {
		notesDao.updateNote(note);
	}

	@Override
	public void deleteNoteById(String id) {
		notesDao.deleteNoteById(id);
	}

	@Override
	public void markComplete(String id) {
		notesDao.markComplete(id);
	}

	@Override
	public List<Note> getAllNotes() {
		return notesDao.getAllNotes();
	}

	@Override
	public void deleteAllNotes() {
		notesDao.deleteAllNotes();
	}

	@Override
	public boolean exist(Note note) {
		return notesDao.exist(note);
	}

}
