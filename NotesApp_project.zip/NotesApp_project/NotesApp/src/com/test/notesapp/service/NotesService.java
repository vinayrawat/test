package com.test.notesapp.service;

import java.util.List;

import com.test.notesapp.model.Note;

public interface NotesService {
	
	Note getNoteById(String id);
	void addNote(Note note);
	void updateNote(Note note);
	void deleteNoteById(String id);
	void markComplete(String id);
	
	List<Note> getAllNotes();
	void deleteAllNotes();
	boolean exist(Note note);

}
