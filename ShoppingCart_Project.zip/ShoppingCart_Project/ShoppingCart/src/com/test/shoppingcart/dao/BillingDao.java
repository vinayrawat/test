package com.test.shoppingcart.dao;

import java.util.List;

import com.test.shoppingcart.model.Cart;
import com.test.shoppingcart.model.Item;

public class BillingDao {


	public enum Category{
		A(10), B(20), C(0);
		
		private double salesTax;
		
		Category(double salesTax){
			this.salesTax = salesTax;
		}
		
		public double getSalesTaxAmount(double price){
			return (salesTax/100) * price;
		}
		
	}
	
	public String generateBill(Cart cart) {
		
		List<Item> itemList = cart.getItem();
		
		if(itemList != null && !itemList.isEmpty()){
			for (Item item : itemList) {
				item.setSalesTax(Category.valueOf(item.getCategory()).getSalesTaxAmount(item.getPrice()));
			}
			
			return getItemisedBill(itemList);
		}
		
		return null;
	}

	private String getItemisedBill(List<Item> itemList) {
		StringBuffer sb = new StringBuffer();
		
		double finalPrice;
		double totalTax = 0;
		double totalPrice = 0;
		
		sb.append("<!DOCTYPE html> <html>  <head>  <title>Retail store</title> ");
		sb.append("<style> table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }  td, th { border: 1px solid #dddddd; text-align: left; padding: 8px; }  tr:nth-child(even) { background-color: #dddddd; } </style>");
		sb.append("</head>  <body>  <h1>Final Itemised Bill</h1> <br/> <hr> <br/> ");
		
		sb.append("<table> <tr> <th>Item</th> <th>Price</th> <th>Sales Tax</th> <th>Final Price</th> </tr>");
		
		for (Item item : itemList) {
			finalPrice = item.getPrice() + item.getSalesTax();
			totalTax += item.getSalesTax();
			totalPrice += item.getPrice();
			
			sb.append("<tr>");
			sb.append("<td>" + item.getName() + "</td>" + "<td>" + item.getPrice() + "</td>" + "<td>" + item.getSalesTax() + "</td>" + "<td>" + finalPrice + "</td>");
			sb.append("</tr>");
		}
		
		sb.append("<tr style='font-weight:bold;'><td></td><td>Total: </td>" + "<td>" + totalTax + "</td>" + "<td>" + totalPrice + "</td>" + "</tr>");
		sb.append("</table>");
		sb.append("</body> </html>");
		
		return sb.toString();
	}

}
