package com.test.shoppingcart.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.test.shoppingcart.dao.BillingDao;
import com.test.shoppingcart.model.Cart;

@Path("/BillingService")
public class BillingService {

   @GET
   @Path("/ping")
   @Produces(MediaType.TEXT_PLAIN)
   public String pingService(){
      return "Yes. The service is up.";
   }   
   
   @POST
   @Path("/generateBill")
   @Produces(MediaType.TEXT_HTML)
   @Consumes(MediaType.APPLICATION_XML)
   public String generateBill(Cart cart){

	   return new BillingDao().generateBill(cart);
   } 
	
}
